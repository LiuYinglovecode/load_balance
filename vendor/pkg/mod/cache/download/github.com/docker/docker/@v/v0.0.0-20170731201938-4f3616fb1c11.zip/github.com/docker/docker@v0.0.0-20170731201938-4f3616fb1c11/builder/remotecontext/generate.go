package remotecontext

//go:generate protoc --gogoslick_out=. tarsum.proto
