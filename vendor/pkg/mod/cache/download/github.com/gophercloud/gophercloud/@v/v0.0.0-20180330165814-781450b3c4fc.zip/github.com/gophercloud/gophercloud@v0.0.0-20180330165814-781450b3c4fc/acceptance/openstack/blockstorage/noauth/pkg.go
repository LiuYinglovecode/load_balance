// The noauth package contains acceptance tests for the Openstack Cinder standalone service.

package noauth
