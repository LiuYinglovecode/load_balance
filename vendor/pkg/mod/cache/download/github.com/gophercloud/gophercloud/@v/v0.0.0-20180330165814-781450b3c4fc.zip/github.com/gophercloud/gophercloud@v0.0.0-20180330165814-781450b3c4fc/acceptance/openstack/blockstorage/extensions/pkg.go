// The extensions package contains acceptance tests for the Openstack Cinder extensions service.

package extensions
