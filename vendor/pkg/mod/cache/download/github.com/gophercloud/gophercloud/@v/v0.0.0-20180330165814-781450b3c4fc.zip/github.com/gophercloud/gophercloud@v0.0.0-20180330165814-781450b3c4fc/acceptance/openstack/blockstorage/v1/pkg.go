// Package v1 contains openstack cinder acceptance tests
package v1
