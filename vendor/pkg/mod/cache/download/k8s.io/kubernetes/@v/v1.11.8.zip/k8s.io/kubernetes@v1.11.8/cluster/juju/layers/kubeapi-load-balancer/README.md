# kubeapi-load-balancer

Simple NGINX reverse proxy to lend a hand in HA kubernetes-master deployments.


